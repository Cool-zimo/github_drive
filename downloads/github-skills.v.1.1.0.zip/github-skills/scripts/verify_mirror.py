#!/usr/bin/env python3
"""本地目录 vs 线上 tree 逐字节校验（git blob sha）。

  python3 scripts/verify_mirror.py ./out --repo Cool-zimo/github_drive
"""
import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import ghlib as G

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def main():
    p = argparse.ArgumentParser()
    p.add_argument("dest")
    p.add_argument("--repo", required=True)
    p.add_argument("--ref", default="main")
    p.add_argument("--as", dest="spec", help="login 或行号；不填用 .active / 第 1 行")
    a = p.parse_args()
    i = G.resolve(ROOT, a.spec)
    print("账号 %s (第 %d 行)" % (i["login"], i["line"]))
    shas = {t["path"]: t["sha"] for t in G.tree(i["token"], a.repo, a.ref)
            if t["type"] == "blob"}
    ok, total, bad = G.verify_mirror(a.dest, shas)
    print("%s vs %s@%s：%d/%d 一致" % (a.dest, a.repo, a.ref, ok, total))
    if bad:
        print("❌", bad[:20], file=sys.stderr)
        return 1
    print("✅ 逐字节一致")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except G.GhError as e:
        print("❌", e, file=sys.stderr)
        sys.exit(1)
