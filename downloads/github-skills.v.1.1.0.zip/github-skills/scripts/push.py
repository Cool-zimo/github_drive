#!/usr/bin/env python3
"""推单个文件，账号可切换。等同 `github push`，便于单独拷出去用。

  python3 scripts/push.py --check
  python3 scripts/push.py --as Cool-zimo --repo Cool-zimo/github_drive \
      --file a.txt --path a.txt -m "msg" --dry-run
"""
import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import ghlib as G

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--as", dest="spec", help="login 或行号；不填则用 .active / 第 1 行")
    p.add_argument("--repo")
    p.add_argument("--file")
    p.add_argument("--path")
    p.add_argument("-m", "--message")
    p.add_argument("--branch", default="main")
    p.add_argument("--dry-run", action="store_true")
    p.add_argument("--check", action="store_true", help="只校验身份，零写入")
    a = p.parse_args()

    i = G.resolve(ROOT, a.spec)
    print("身份校验通过：%s (第 %d 行，%s，值不显示)" %
          (i["login"], i["line"], os.path.basename(i["source"])))
    if a.check:
        print("--check：未做任何写入")
        return 0
    if not (a.repo and a.file and a.path and a.message):
        print("缺参数：--repo --file --path -m 都要给", file=sys.stderr)
        return 1
    G.precheck_push(i, a.repo)
    print("推送   %s → %s:%s  -m %r" % (a.file, a.branch, a.path, a.message))
    if a.dry_run:
        print("DRY-RUN：未调用 API")
        return 0
    sha = G.put_file(i["token"], a.repo, a.path, a.file, a.message, a.branch)
    print("✅ commit %s → %s:%s" % (sha[:12], a.repo, a.path))
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except G.GhError as e:
        print("❌", e, file=sys.stderr)
        sys.exit(1)
