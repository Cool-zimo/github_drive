#!/usr/bin/env python3
"""git clone 被 403 时用：tree + contents 镜像拉取，并逐字节校验。

  python3 scripts/clone_via_api.py forrestchang/andrej-karpathy-skills ./out
"""
import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import ghlib as G

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def main():
    p = argparse.ArgumentParser()
    p.add_argument("repo")
    p.add_argument("dest")
    p.add_argument("--ref", default="main")
    p.add_argument("--as", dest="spec", help="login 或行号；不填用 .active / 第 1 行")
    a = p.parse_args()
    i = G.resolve(ROOT, a.spec)
    print("账号 %s (第 %d 行)" % (i["login"], i["line"]))
    tok = i["token"]
    n, size, shas = G.pull_repo(tok, a.repo, a.dest, a.ref)
    ok, total, bad = G.verify_mirror(a.dest, shas)
    print("%s@%s → %s：%d 文件 / %d 字节，校验 %d/%d" %
          (a.repo, a.ref, a.dest, n, size, ok, total))
    if bad:
        print("❌", bad[:10], file=sys.stderr)
        return 1
    print("✅ 逐字节一致")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except G.GhError as e:
        print("❌", e, file=sys.stderr)
        sys.exit(1)
