#!/usr/bin/env python3
"""Pages 构建状态 + 轮询等待落定。

  python3 scripts/pages_status.py Cool-zimo/github_drive --wait
"""
import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import ghlib as G

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def main():
    p = argparse.ArgumentParser()
    p.add_argument("repo")
    p.add_argument("--wait", action="store_true", help="轮询到 built/errored")
    p.add_argument("--as", dest="spec", help="login 或行号；不填用 .active / 第 1 行")
    a = p.parse_args()
    i = G.resolve(ROOT, a.spec)
    print("账号 %s (第 %d 行)" % (i["login"], i["line"]))
    tok = i["token"]
    st, d = G.pages(tok, a.repo)
    print("Pages:", d.get("status") if st == 200 else "未启用(HTTP %s)" % st,
          "|", d.get("html_url", ""), "| branch:", (d.get("source") or {}).get("branch"))
    if st != 200:
        return 0
    st2, b = G.latest_build(tok, a.repo)
    print("最新构建:", b.get("status"), "commit:", str(b.get("commit"))[:12],
          "err:", (b.get("error") or {}).get("message"))
    if a.wait:
        print("等待落定：")
        print("最终状态:", G.poll_pages(tok, a.repo))
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except G.GhError as e:
        print("❌", e, file=sys.stderr)
        sys.exit(1)
