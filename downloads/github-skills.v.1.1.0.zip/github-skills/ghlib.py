#!/usr/bin/env python3
"""GitHub REST 薄封装。零第三方依赖，只做本机实测过的那几件事。

账号约定（多账号，不固定）：
  .tokens 每行一个 PAT；行号即账号编号。
  当前账号写在 .active（一行：login 或行号）；没有 .active 时默认第 1 行。
  单次覆盖：--as <login|行号> / `github as <账号> <命令>` / 直呼账号名。
  写操作前解析身份并校验；指定了账号就必须精确匹配，绝不降级到别的行。
"""
import base64
import hashlib
import json
import os
import urllib.error
import urllib.parse
import urllib.request

API = "https://api.github.com"
VERSION = "1.1.0"
BASE_HEADERS = {
    "Accept": "application/vnd.github+json",
    "X-GitHub-Api-Version": "2022-11-28",
    "User-Agent": "github-skills/" + VERSION,
}


class GhError(Exception):
    pass


# ---------------------------------------------------------------- 账号

def load_token(root, line=1):
    """按 包根 → 上一级 → .tokens → .token 找，返回 (token, 来源路径)。值永不打印。"""
    for base in (root, os.path.dirname(root)):
        for name in (".tokens", ".token"):
            path = os.path.join(base, name)
            if not os.path.isfile(path):
                continue
            rows = [r.strip() for r in open(path, encoding="utf-8").read().splitlines() if r.strip()]
            if line == 0 or line > len(rows):
                raise GhError("%s 只有 %d 行，取不到第 %d 行" % (path, len(rows), line))
            return rows[line - 1], path
    raise GhError("找不到 .tokens / .token，参考 .tokens.example")


def token_lines(root):
    """返回 [(行号, token, 来源路径)]，用于账号探测。值永不打印。"""
    for base in (root, os.path.dirname(root)):
        for name in (".tokens", ".token"):
            path = os.path.join(base, name)
            if os.path.isfile(path):
                rows = [r.strip() for r in open(path, encoding="utf-8").read().splitlines() if r.strip()]
                return [(i + 1, r, path) for i, r in enumerate(rows)]
    return []


def read_active(root):
    """读 .active，返回 spec 字符串或 None。"""
    p = os.path.join(root, ".active")
    if os.path.isfile(p):
        v = open(p, encoding="utf-8").read().strip()
        if v:
            return v
    return None


def write_active(root, spec):
    """设当前账号。写的是 login 或行号，不写 token。"""
    p = os.path.join(root, ".active")
    if spec is None:
        if os.path.isfile(p):
            os.remove(p)
    else:
        with open(p, "w", encoding="utf-8") as f:
            f.write(str(spec))
    return p


def probe(token):
    """调 /user，返回 (HTTP状态, 数据)。失效账号不抛异常。"""
    return req("GET", "/user", token)


def accounts(root):
    """探测所有账号：[(行号, login, id, type, scopes, 状态)]。不显示 token。"""
    out = []
    for line, tok, path in token_lines(root):
        st, me = probe(tok)
        if st == 200:
            out.append((line, me.get("login"), me.get("id"), me.get("type"),
                        me.get("scopes", []), "ok"))
        else:
            out.append((line, "-", "-", "-", [], "HTTP %s 失效/无权限" % st))
    return out


def resolve(root, spec=None):
    """解析出一个账号。返回 dict：token / line / login / id / source / spec。

    spec 为 None → .active → 第 1 行；为 int 或数字串 → 行号；
    为 login 字符串 → 遍历各行精确匹配，找不到直接报错，不降级。
    """
    if spec is None:
        spec = read_active(root)
    if spec is None:
        spec = 1

    by_login = None
    if isinstance(spec, int) or str(spec).isdigit():
        line = int(spec)
    else:
        by_login = str(spec)
        line = None
        for n, tok, _ in token_lines(root):
            st, me = probe(tok)
            if st == 200 and me.get("login") == by_login:
                line = n
                break
        if line is None:
            known = ", ".join(str(a[1]) for a in accounts(root) if a[5] == "ok") or "(无有效账号)"
            raise GhError("账号 %s 不在 .tokens 里（有效账号：%s）—— 不降级" % (by_login, known))

    tok, path = load_token(root, line)
    st, me = req("GET", "/user", tok)
    if st != 200:
        raise GhError("第 %d 行 /user → HTTP %s %s" % (line, st, me.get("message", "")))
    login = me.get("login")
    if by_login and login != by_login:
        raise GhError("第 %d 行实际是 %s，不是 %s —— 拒绝" % (line, login, by_login))
    expect = os.environ.get("GH_EXPECT_LOGIN")
    if expect and login != expect:
        raise GhError("环境变量 GH_EXPECT_LOGIN=%s，实际 %s —— 拒绝" % (expect, login))
    return {"token": tok, "line": line, "login": login, "id": me.get("id"),
            "scopes": me.get("scopes", []), "source": path, "spec": spec}


def precheck_push(ident, full):
    """写操作前查目标仓库权限。无 push 权限直接拒绝并提示换账号。"""
    st, d = req("GET", "/repos/" + full, ident["token"])
    if st != 200:
        raise GhError("%s 读取 %s → HTTP %s（仓库不存在或该账号无访问权）" %
                      (ident["login"], full, st))
    perm = d.get("permissions") or {}
    if not perm.get("push"):
        raise GhError("%s 对 %s 无 push 权限（admin=%s pull=%s）—— 换账号：github as <账号> ... 或 github use <账号>" %
                      (ident["login"], full, perm.get("admin"), perm.get("pull")))
    return perm


# ---------------------------------------------------------------- HTTP

def req(method, path, token, body=None, params=None):
    url = API + path
    if params:
        url += "?" + urllib.parse.urlencode(params)
    headers = dict(BASE_HEADERS, Authorization="Bearer " + token)
    data = None
    if body is not None:
        data = json.dumps(body).encode()
        headers["Content-Type"] = "application/json"
    r = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(r, timeout=60) as f:
            return f.status, json.loads(f.read() or b"{}")
    except urllib.error.HTTPError as e:
        raw = e.read()
        try:
            return e.code, json.loads(raw or b"{}")
        except ValueError:
            return e.code, {"message": raw.decode("utf-8", "replace")[:300]}
    except Exception as e:
        return -1, {"message": str(e)}


def need(method, path, token, body=None, params=None, what=""):
    st, d = req(method, path, token, body, params)
    if not 200 <= st < 300:
        raise GhError("%s：HTTP %s %s" % (what or path, st, d.get("message", "")))
    return d


def whoami(token):
    return need("GET", "/user", token, what="校验身份")


def repo(token, full):
    return need("GET", "/repos/" + full, token, what="读取仓库")


def tree(token, full, ref="main"):
    d = need("GET", "/repos/%s/git/trees/%s" % (full, urllib.parse.quote(ref, safe="")),
             token, params={"recursive": "1"}, what="读取文件树")
    if d.get("truncated"):
        raise GhError("文件树被截断（truncated=true），不适合做镜像校验")
    return d.get("tree", [])


def contents(token, full, path, ref="main"):
    p = urllib.parse.quote(path, safe="/")
    return need("GET", "/repos/%s/contents/%s" % (full, p), token,
                params={"ref": ref}, what="读取 " + path)


def blob_sha(data):
    """git blob sha —— 与 API tree 的 sha 可直接比对，用于逐字节校验。"""
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\x00" + data).hexdigest()


def pull_repo(token, full, dest, ref="main"):
    """git clone 被 403 的环境用：tree + contents base64 落盘。返回 (文件数, 字节数, sha 表)。"""
    items = [t for t in tree(token, full, ref) if t["type"] == "blob"]
    shas = {}
    total = 0
    for t in items:
        path = t["path"]
        d = contents(token, full, path, ref)
        raw = base64.b64decode(d.get("content", "") + "=" * (-len(d.get("content", "")) % 4))
        out = os.path.join(dest, path)
        parent = os.path.dirname(out)
        if parent:
            os.makedirs(parent, exist_ok=True)
        with open(out, "wb") as f:
            f.write(raw)
        shas[path] = t["sha"]
        total += len(raw)
    return len(items), total, shas


def verify_mirror(dest, shas):
    """本地文件 git blob sha vs 线上 tree。返回 (通过数, 总数, 失败列表)。"""
    bad = []
    local = []
    for base, dirs, files in os.walk(dest):
        dirs[:] = [x for x in dirs if x != ".git"]
        for fn in files:
            local.append(os.path.relpath(os.path.join(base, fn), dest).replace(os.sep, "/"))
    for rel in sorted(shas):
        p = os.path.join(dest, rel)
        if not os.path.isfile(p) or blob_sha(open(p, "rb").read()) != shas[rel]:
            bad.append(rel)
    extra = ["+多出:" + x for x in local if x not in shas and x != ".gitkeep"]
    return len(shas) - len(bad), len(shas), bad + extra


def put_file(token, full, path, local_path, message, branch="main"):
    """推单个文件，自动带 sha 避免 409/422。返回 commit sha。"""
    data = open(local_path, "rb").read()
    body = {"message": message, "content": base64.b64encode(data).decode(), "branch": branch}
    p = urllib.parse.quote(path, safe="/")
    st, cur = req("GET", "/repos/%s/contents/%s" % (full, p), token, params={"ref": branch})
    if st == 200:
        body["sha"] = cur["sha"]
    elif st != 404:
        raise GhError("预取 sha 失败：HTTP %s %s" % (st, cur.get("message", "")))
    d = need("PUT", "/repos/%s/contents/%s" % (full, p), token, body=body, what="推送 " + path)
    return d["commit"]["sha"]


def fast_forward(token, full, branch, sha, expect_base=None):
    """快进分支。force=false；基线不符就拒绝，不覆盖他人提交。"""
    ref = need("GET", "/repos/%s/git/ref/heads/%s" % (full, branch), token, what="读取 ref")
    old = ref["object"]["sha"]
    if expect_base and not old.startswith(expect_base):
        raise GhError("基线已变：%s，期望 %s* —— 停止" % (old, expect_base))
    d = need("PATCH", "/repos/%s/git/refs/heads/%s" % (full, branch), token,
             body={"sha": sha, "force": False}, what="快进")
    return old, d["object"]["sha"]


def compare(token, full, base, head):
    return need("GET", "/repos/%s/compare/%s...%s" % (full, base, head), token, what="比对分支")


def create_repo(token, name, private=False, description="", auto_init=True):
    return need("POST", "/user/repos", token,
                body={"name": name, "private": private, "description": description,
                      "auto_init": auto_init}, what="建仓")


def pages(token, full):
    return req("GET", "/repos/" + full + "/pages", token)


def latest_build(token, full):
    return req("GET", "/repos/" + full + "/pages/builds/latest", token)


def poll_pages(token, full, tries=8, sleep=8, log=print):
    import time
    last = "unknown"
    for i in range(tries):
        st, d = latest_build(token, full)
        last = d.get("status", "unknown")
        err = (d.get("error") or {}).get("message")
        log("  [%d] build=%s commit=%s err=%s" % (i, last, str(d.get("commit"))[:12], err))
        if last in ("built", "errored"):
            return last
        time.sleep(sleep)
    return last


def pulls(token, full, state="open"):
    return need("GET", "/repos/" + full + "/pulls", token,
                params={"state": state, "per_page": "20"}, what="读取 PR")


def collaborators(token, full):
    return need("GET", "/repos/" + full + "/collaborators", token, what="读取协作者")
